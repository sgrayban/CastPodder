#
# $Id: __init__.py 68 2006-04-26 20:14:35Z sgrayban $
#

version = '3.4.2'
