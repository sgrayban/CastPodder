#!/bin/bash
# distribution file for CastPodder
# Copyright (c) 2005-2006 Scott Grayban and the CastPodder Team
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# $Id: make-distribution.sh 107 2006-07-25 06:36:39Z sgrayban $

# Copy the working directory to a dist one first
cd ..
cp -r trunk castpodder
cd castpodder

# remove all pyc files so that they don't get "accidently" installed
echo "Deleting all CVS, pyc & pyo files..."

for PYC in `find -name "*.pyc" -type f`; do /bin/rm -f $PYC; done
for PYO in `find -name "*.pyo" -type f`; do /bin/rm -f $PYO; done

# remove all SVN files so that they don't get "accidently" installed
for SVNDIR in `find . -type d -name .svn` ; do
    /bin/rm -rf $SVNDIR
done

# CVS commits/checkouts does some funky things that I dont like with
# file permissions so I'll fix them here

find . -type f -exec chmod 664 {} ";"
find . -name "*.sh" -type f -exec chmod 755 {} ";"
chmod 755 CastPodderGui.py

# Copy the new spec file
echo -e "\nCopy the new spec file..."
cp -f CastPodder.spec /home/sgrayban/RPM/SPECS

# make the tarbal now
echo -e "\nMaking tarball..."
cd ..
tar -jcf CastPodder-5.3.tar.bz2 castpodder/

# remove the castpodder-dist back to castpodder
/bin/rm -fr castpodder
cd /home/sgrayban/cvs/castpodder

echo -e "\nDistribution made...."
