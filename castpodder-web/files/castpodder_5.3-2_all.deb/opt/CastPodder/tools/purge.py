#!/usr/bin/env python
#
# Copyright (c) 2005-2006 Scott Grayban and the CastPodder Team
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# $Id: purge.py 96 2006-07-10 19:50:46Z sgrayban $

from ipodder import players
import os.path

player = players.get(players.player_types()[0])
bad = [t for t in player.iTunes.LibraryPlaylist.Tracks
       if not (hasattr(t, 'Location') and t.Location and os.path.isfile(t.Location))]
print len([t.Delete() for t in bad])
